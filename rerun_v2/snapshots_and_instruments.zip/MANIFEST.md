# B1 audit re-run — scoreable package (2026-11-24)

## Scope decision (settled): DOCUMENTATION-BASED audit
Scores DOCUMENTED security posture (matching the original method and the frozen extract_signals.py),
not implementation correctness. State this limitation in Section VIII. Snapshots therefore contain
each server's docs + manifest/config + .github/workflows (D6 evidence), captured at the pinned SHA.
D6 signed-release/SBOM is additionally checked via the GitHub Releases API at the pinned SHA.

## Contents
- units_pinned.csv ............ 24 units, repo, subpath, pinned HEAD SHA (resolved 2026-11-24)
- snap_docs/<id>/ ............. docs + manifest/config snapshot per unit, at the pinned SHA (score from these)
- rubric_v2.0_DRAFT.md ........ revised rubric (D1 richness, D5 narrowed, D6 API-based, +NA). SIGN OFF, then git-tag to freeze.
- extract_signals_FROZEN_724f970.py . deterministic baseline; run before human scoring.
- audit_rescore_TEMPLATE.xlsx . blank per-rater workbook (duplicate for R1', R2'); 0/1/2/NA dropdowns.
- repo_layouts.txt ............ each repo's top-level layout (to confirm server subpath / suite calls).

## Remaining before scoring (human)
1. SUITE handling (proposed): EXCLUDE C11 aws-mcp (dozens of AWS servers; not one server). CONFIRM C03 cloudflare
   and C10 snowflake-labs/mcp (check repo_layouts) — exclude or scope to the one designated server. R01-R07 are
   already single servers in one monorepo (keep). Excluding C11 (+ any confirmed suites) lowers N from 24; state N.
2. RUBRIC sign-off on the D1/D6/D5/NA changes, then git-tag rubric_v2.0 immutable.
3. RATERS: R1' / R2' score blind from snap_docs/ in the same week; R3' adjudicates disagreements. ("rater b" = R2'.)
