# Cloudflare MCP Server

Model Context Protocol (MCP) is a [new, standardized protocol](https://modelcontextprotocol.io/introduction) for managing context between large language models (LLMs) and external systems. In this repository, you can find several MCP servers allowing you to connect to Cloudflare's service from an MCP client (e.g. Cursor, Claude) and use natural language to accomplish tasks through your Cloudflare account.

These MCP servers allow your [MCP Client](https://modelcontextprotocol.io/clients) to read configurations from your account, process information, make suggestions based on data, and even make those suggested changes for you. All of these actions can happen across Cloudflare's many services including application development, security and performance.

Every server in this repository exposes a stateless Streamable HTTP handler at `/mcp` through a fresh SDK v2 server factory. The retired `/sse` URL answers every request with a `410 Gone` Problem Details response that names the `/mcp` URL; MCP clients show its message in their connection error. Modern 2026 requests and stateless 2025 requests share the same request-scoped implementation without an MCP protocol session. OAuth, credentials, account selection, application caches, and product Durable Objects remain application/security state where required.

Cloudflare offers the following MCP servers. The domain-specific servers are included in this repository, while the recommended Cloudflare API MCP Server is maintained in [`cloudflare/mcp`](https://github.com/cloudflare/mcp):

| Server Name                                                                      | Description                                                                                     | Server URL                                  |
| -------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------- |
| [**Cloudflare API MCP Server (recommended)**](https://github.com/cloudflare/mcp) | Best when you want broad access across Cloudflare's APIs through code execution                 | `https://mcp.cloudflare.com/mcp`            |
| [**Documentation server**](/apps/docs-ai-search)                                 | Get up-to-date reference information on Cloudflare                                              | `https://docs.mcp.cloudflare.com/mcp`       |
| [**Container server**](/apps/sandbox-container)                                  | Spin up a sandbox development environment                                                       | `https://containers.mcp.cloudflare.com/mcp` |
| [**Browser Run server**](/apps/browser-rendering)                                | Fetch web pages, convert them to markdown and take screenshots                                  | `https://browser.mcp.cloudflare.com/mcp`    |
| [**Digital Experience Monitoring server**](/apps/dex-analysis)                   | Get quick insight on critical applications for your organization                                | `https://dex.mcp.cloudflare.com/mcp`        |
| [**Cloudflare One CASB server**](/apps/cloudflare-one-casb)                      | Quickly identify any security misconfigurations for SaaS applications to safeguard users & data | `https://casb.mcp.cloudflare.com/mcp`       |
| [**Cloudflare Blog server**](/apps/cloudflare-blog)                              | Search and read posts from the Cloudflare Blog                                                  | `https://blog.mcp.cloudflare.com/mcp`       |
| [**Demo Day server**](/apps/demo-day)                                            | Demonstrate a minimal Cloudflare MCP server                                                     | `https://demo-day.mcp.cloudflare.com/mcp`   |

<details>
<summary><strong>Deprecated servers</strong></summary>

Please migrate to the [Cloudflare API MCP Server](https://mcp.cloudflare.com/mcp) at your earliest convenience.

| Server Name                                             | Description                                                         | Server URL                                     |
| ------------------------------------------------------- | ------------------------------------------------------------------- | ---------------------------------------------- |
| [**AI Gateway server**](/apps/ai-gateway)               | Search your logs, get details about the prompts and responses       | `https://ai-gateway.mcp.cloudflare.com/mcp`    |
| [**Audit Logs server**](/apps/auditlogs)                | Query audit logs and generate reports for review                    | `https://auditlogs.mcp.cloudflare.com/mcp`     |
| [**AutoRAG server**](/apps/autorag)                     | Search and query account AutoRAG instances                          | `https://autorag.mcp.cloudflare.com/mcp`       |
| [**DNS Analytics server**](/apps/dns-analytics)         | Optimize DNS performance and debug issues based on current setup    | `https://dns-analytics.mcp.cloudflare.com/mcp` |
| [**GraphQL server**](/apps/graphql)                     | Get analytics data using Cloudflare's GraphQL API                   | `https://graphql.mcp.cloudflare.com/mcp`       |
| [**Logpush server**](/apps/logpush)                     | Get quick summaries for Logpush job health                          | `https://logs.mcp.cloudflare.com/mcp`          |
| [**Observability server**](/apps/workers-observability) | Debug and get insight into your application's logs and analytics    | `https://observability.mcp.cloudflare.com/mcp` |
| [**Radar server**](/apps/radar)                         | Explore Cloudflare Radar internet insights                          | `https://radar.mcp.cloudflare.com/mcp`         |
| [**Workers Bindings server**](/apps/workers-bindings)   | Build Workers applications with storage, AI, and compute primitives | `https://bindings.mcp.cloudflare.com/mcp`      |
| [**Workers Builds server**](/apps/workers-builds)       | Get insights and manage your Cloudflare Workers Builds              | `https://builds.mcp.cloudflare.com/mcp`        |

</details>

## Which Cloudflare MCP server should you use?

Cloudflare provides two categories of MCP servers:

- **Cloudflare API MCP Server** (`mcp.cloudflare.com`) in [`cloudflare/mcp`](https://github.com/cloudflare/mcp):
  best when you want broad access across Cloudflare's APIs through code execution.
- **Domain-specific servers** (`*.mcp.cloudflare.com`) in this repository:
  best when you want curated, typed tools for a specific Cloudflare product area.

### When should you use each?

Use the **Cloudflare API MCP Server** when:

- you need broad API coverage across many Cloudflare products
- you prefer a smaller set of general-purpose tools
- your workflow is better served by code execution

Use the **domain-specific servers** in this repository when:

- you want purpose-built tools for a specific product area
- you want more guided, typed interactions
- you are working primarily within one Cloudflare domain such as Browser Run or containers

Learn more about the Cloudflare API MCP Server here: [`cloudflare/mcp`](https://github.com/cloudflare/mcp).

## Connect to an MCP server

Connect any MCP client with remote-server support directly to a URL in the table above. [Cloudflare AI Playground](https://playground.ai.cloudflare.com/) also accepts server URLs in its interface.

## Using Cloudflare's MCP servers from the OpenAI Responses API

To use one of Cloudflare's MCP servers with [OpenAI's responses API](https://openai.com/index/new-tools-and-features-in-the-responses-api/), you will need to provide the Responses API with an API token that has the scopes (permissions) required for that particular MCP server.

For example, to use the [Browser Run MCP server](https://github.com/cloudflare/mcp-server-cloudflare/tree/main/apps/browser-rendering) with OpenAI, create an API token in the Cloudflare dashboard [here](https://dash.cloudflare.com/profile/api-tokens), with the following permissions:

<img width="937" alt="Screenshot 2025-05-21 at 10 38 02 AM" src="https://github.com/user-attachments/assets/872e253f-23ce-43b3-983c-45f9d0f66100" />

## Need access to more Cloudflare tools?

We're continuing to add more functionality to this remote MCP server repo. If you'd like to leave feedback, file a bug or provide a feature request, [please open an issue](https://github.com/cloudflare/mcp-server-cloudflare/issues/new/choose) on this repository

## Troubleshooting

"Claude's response was interrupted ... "

If you see this message, Claude likely hit its context-length limit and stopped mid-reply. This happens most often on servers that trigger many chained tool calls such as the observability server.

To reduce the chance of running in to this issue:

- Try to be specific, keep your queries concise.
- If a single request calls multiple tools, try to to break it into several smaller tool calls to keep the responses short.

## Paid Features

Some features may require a paid Cloudflare Workers plan. Ensure your Cloudflare account has the necessary subscription level for the features you intend to use.

## Contributing

Interested in contributing, and running this server locally? See [CONTRIBUTING.md](CONTRIBUTING.md) to get started.
