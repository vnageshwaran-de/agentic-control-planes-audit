# workers-builds

## 0.3.0

### Minor Changes

- dfd49e5: Retire the `/sse` URL and upgrade to `@cloudflare/workers-oauth-provider` 1.2.4.

  - Every request to `/sse` now returns `410 Gone` with an `application/problem+json` body naming the server's `/mcp` URL, before any authentication. `/sse` used to serve Streamable HTTP as an alias of `/mcp`; clients configured with it must switch to `/mcp`. MCP SDK v1 and v2 clients show the message in their connection error. It is not a redirect, because OAuth clients that follow one reject the `/mcp` protected resource metadata with an error that never mentions `/mcp`.
  - The OAuth protected resource is now `<origin>/mcp`, and every token is bound to it. Grants bound to `/mcp` keep working. Grants bound to `/sse`, or to the bare origin that 0.x advertised at the root metadata URL, fail their next refresh with `invalid_grant` (workers-oauth-provider 1.2.4), and the client signs in again at `/mcp`.
  - The consent page uses the provider's consent helpers. The authorization request stays server-side and the page posts only a single-use handle bound to the browser. Cancel now sends `access_denied` back to the MCP client. The page shows the redirect URI, the publishing domain of a Client ID Metadata Document client, and a warning when the tokens go to a local app.
  - Cloudflare sign-in uses `beginUpstream()` / `finishUpstream()` in place of the hand-rolled KV state and session cookie. Two tabs can authorize at once, and declining at Cloudflare sends `access_denied` back to the MCP client.
  - Remembered consent uses `isConsentRemembered()`. Approvals made before this change aren't carried over, so each browser sees the consent page once more.
  - Direct Cloudflare API tokens are validated for the `/mcp` resource.

### Patch Changes

- 0702829: A direct Cloudflare credential that Cloudflare rejects as expired or unknown (`403 9109: Invalid access token`) now gets `401 invalid_token`, as the MCP authorization spec requires for invalid or expired tokens. Before, it got `403 insufficient_scope`, which sends clients through a scope step-up instead of re-authenticating. A valid token that lacks access still gets `403 insufficient_scope`.
- Updated dependencies [0702829]
- Updated dependencies [dfd49e5]
  - @repo/mcp-common@0.21.0

## 0.2.6

### Patch Changes

- 995f7a1: Deprecate the Workers Builds MCP server in favor of the Cloudflare API MCP server at https://mcp.cloudflare.com/mcp. The existing tools keep working for now.
- ab883e5: Send `User-Agent: mcp-server-cloudflare (<server>; +https://github.com/cloudflare/mcp-server-cloudflare)` on every outbound request to Cloudflare, with `<server>` taken from the new `serverId` option of `createPublicMcpApp()` / `createAuthenticatedMcpApp()`. It covers the Cloudflare SDK client, `fetchCloudflareApi`, the OAuth token exchange and refresh, the identity probe, and the direct `fetch` calls in the Radar, URL Scanner, GraphQL, DEX, Blog and docs tools.
- Updated dependencies [ab883e5]
  - @repo/mcp-common@0.20.11

## 0.2.5

### Patch Changes

- b9e6d76: Return an actionable `410 Gone` Problem Details response when a client attempts the removed HTTP+SSE transport with `GET /sse`. The response explains that clients can configure the existing `/sse` URL to use Streamable HTTP or, preferably, move to `/mcp` for future compatibility. It preserves query parameters, identifies the recommended replacement in a `Link` header, and is available before OAuth authentication. Streamable HTTP `POST` requests continue to work on both `/sse` and `/mcp`.
- Updated dependencies [b9e6d76]
  - @repo/mcp-common@0.20.10

## 0.2.4

### Patch Changes

- Updated dependencies [12a9a61]
  - @repo/mcp-common@0.20.9

## 0.2.3

### Patch Changes

- Updated dependencies [4e1e6ab]
  - @repo/mcp-common@0.20.8

## 0.2.2

### Patch Changes

- 1df6213: Migrate all MCP servers to fresh SDK v2 factories with default stateless 2025 compatibility, request-scoped auth/context, and no live protocol Durable Object or SSE session state. Upgrade the released MCP stack to `agents@0.20.1`, `@modelcontextprotocol/server@2.0.0`, `@modelcontextprotocol/client@2.0.0`, and SDK v1 compatibility package `@modelcontextprotocol/sdk@1.30.0`, using the isolated `agents/mcp/server` stateless handler. Keep `/sse` as a URL alias for the same Streamable HTTP handler as `/mcp`, without retaining the deprecated HTTP+SSE transport. Assemble every deployment through canonical public/authenticated app modules, prune obsolete app-level routing dependencies, and expose a tracked registration context instead of the raw SDK server. Preserve append-only Durable Object migration history while explicitly deleting retired protocol classes, preserve application/security state, upgrade the OAuth provider to 0.8.2 with exact resource matching, bound MCP request bodies, and require explicit Workers Builds identifiers.
- Updated dependencies [1df6213]
  - @repo/mcp-common@0.20.7

## 0.2.1

### Patch Changes

- Updated dependencies [cb01861]
  - @repo/mcp-common@0.20.6

## 0.2.0

### Minor Changes

- f625075: Centralize Cloudflare account resolution and remove the account-management tools.

  The `accounts_list` and `set_active_account` tools are removed. Account scoping is now
  resolved automatically by an `AccountManager` (via the new `server.accountTool()`
  registration), in priority order:

  1. **Auth-pinned account** — an account-scoped API token's account, or an OAuth token with a
     single account, is used automatically (no `account_id` parameter is exposed).
  2. **`cf-account-id` request header** — for tokens that can access multiple accounts, set this
     header in your MCP client config to pick an account.
  3. **`account_id` tool argument** — for multi-account tokens, account-scoped tools expose an
     optional `account_id` parameter; when omitted (and no header is set) the tool returns an
     error listing the accounts you can use. Multi-account credentials also list their accounts
     in the server's `initialize` instructions.

  All tool error responses now set `isError: true` so clients can distinguish failures.

### Patch Changes

- a358e69: Upgrade `@cloudflare/workers-oauth-provider` 0.4.0 → 0.7.0.

  No tool or behavior changes. The only API change affecting this repo is that
  `TokenExchangeCallbackOptions` now carries a required `grantId` field, which only
  touched a test fixture (the provider supplies it at runtime).

- f625075: Upgrade core dependencies: `agents` 0.2.19 → 0.13.3, `@modelcontextprotocol/sdk` 1.20.2 →
  1.29.0, `zod` 3 → 4, and `ai` 4 → 6.

  No user-facing tool or behavior changes. Internal adjustments for the new versions:

  - `zod` 4: `z.record(...)` now takes an explicit key schema; `z.string().ip()` replaced with
    `z.ipv4()`/`z.ipv6()` validation; dropped the removed `objectOutputType` helper.
  - `agents` 0.13: `McpAgent` env generic is constrained to `Cloudflare.Env`.
  - MCP SDK 1.29: tool `annotations` hints must be flat (`{ title, readOnlyHint, ... }`) — fixes a
    latent bug where nested hints were silently ignored.
  - `ai` 6: eval tooling updated (`LanguageModel`, `inputSchema`, `stopWhen`/`stepCountIs`, tool-call `input`).

## 0.1.13

### Patch Changes

- Updated dependencies [f77355c]
  - @repo/mcp-common@0.20.5

## 0.1.12

### Patch Changes

- 50926ec: Bump @cloudflare/workers-oauth-provider to ^0.4.0, add resourceMatchOriginOnly migration flag and 30-day refresh token TTL
- Updated dependencies [50926ec]
  - @repo/mcp-common@0.20.4

## 0.1.11

### Patch Changes

- Updated dependencies [01a172e]
  - @repo/mcp-common@0.20.3

## 0.1.10

### Patch Changes

- 99e2282: Move docs MCP server to use AI Search
- Updated dependencies [99e2282]
  - @repo/mcp-common@0.20.2
  - @repo/mcp-observability@0.32.5

## 0.1.9

### Patch Changes

- Updated dependencies [7fc3f18]
  - @repo/mcp-common@0.20.1

## 0.1.8

### Patch Changes

- 847fc1f: Update cloudflare-oauth-handler
- Updated dependencies [f9f0bb6]
- Updated dependencies [847fc1f]
  - @repo/mcp-common@0.20.0
  - @repo/mcp-observability@0.32.4

## 0.1.7

### Patch Changes

- 43f493d: Update agent + modelcontextprotocol deps
- Updated dependencies [43f493d]
  - @repo/mcp-observability@0.32.3
  - @repo/mcp-common@0.19.3

## 0.1.6

### Patch Changes

- 24dd872: feat: Add MCP tool titles and hints to all Cloudflare tools
- Updated dependencies [24dd872]
  - @repo/mcp-common@0.19.2

## 0.1.5

### Patch Changes

- dffbd36: Use proper wrangler deploy in all servers so we get the name and version

## 0.1.4

### Patch Changes

- 7422e71: Update MCP sdk
- Updated dependencies [7422e71]
  - @repo/mcp-observability@0.32.2
  - @repo/mcp-common@0.19.1

## 0.1.3

### Patch Changes

- cc6d41f: Update agents deps & modelcontextprotocol
- Updated dependencies [1833c6d]
- Updated dependencies [cc6d41f]
  - @repo/mcp-common@0.19.0
  - @repo/mcp-observability@0.32.1

## 0.1.2

### Patch Changes

- Updated dependencies [f885d07]
  - @repo/mcp-common@0.18.0

## 0.1.1

### Patch Changes

- Updated dependencies [83e2d19]
  - @repo/mcp-common@0.17.1

## 0.1.0

### Minor Changes

- 6cf52a6: Support AOT tokens

### Patch Changes

- 0fc4439: Update agents and modelcontext dependencies
- Updated dependencies [6cf52a6]
- Updated dependencies [0fc4439]
  - @repo/mcp-observability@0.32.0
  - @repo/mcp-common@0.17.0

## 0.0.4

### Patch Changes

- 3677a18: Remove extraneous log
- Updated dependencies [3677a18]
  - @repo/mcp-common@0.16.3

## 0.0.3

### Patch Changes

- 86c2e4f: Add API token passthrough auth
- Updated dependencies [86c2e4f]
  - @repo/mcp-common@0.16.2

## 0.0.2

### Patch Changes

- cf3771b: chore: add suffixes to common files in apps and packages

  It can be confusing switching between 16 files named 'index.ts', or 3 files named workers.ts. This change renames common files to have suffixes such as .types.ts, .api.ts, etc. to make it easier to work across files in the monorepo.

- Updated dependencies [cf3771b]
  - @repo/mcp-common@0.16.1
  - @repo/mcp-observability@0.31.1
