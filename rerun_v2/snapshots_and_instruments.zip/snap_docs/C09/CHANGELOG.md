# Changelog

All notable changes to the Heroku Platform MCP Server will be documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and uses
[Conventional Commits](https://www.conventionalcommits.org/).

## [1.2.15](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.14...mcp-server-v1.2.15) (2026-11-20)


### Dependencies

* bump @hono/node-server from 2.1.5 to 2.1.8 ([#314](https://github.com/heroku/heroku-mcp-server/issues/314)) ([8408ff2](https://github.com/heroku/heroku-mcp-server/commit/8408ff21b880913573af5a1b9f4ee489f2775137))
* bump hono from 4.13.13 to 4.13.18 ([#315](https://github.com/heroku/heroku-mcp-server/issues/315)) ([248ad80](https://github.com/heroku/heroku-mcp-server/commit/248ad80eba397a06d67afc65cf266adeea7133ca))

## [1.2.14](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.13...mcp-server-v1.2.14) (2026-11-09)


### Dependencies

* bump @modelcontextprotocol/sdk from 1.32.1 to 1.32.2 ([#312](https://github.com/heroku/heroku-mcp-server/issues/312)) ([0f7d07f](https://github.com/heroku/heroku-mcp-server/commit/0f7d07fc00761bdf4ec97866ae6a6014eca41b2a))

## [1.2.13](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.12...mcp-server-v1.2.13) (2026-10-29)


### Bug Fixes

* **repl:** prefer local Heroku CLI over npx and shut down idle REPL process ([#308](https://github.com/heroku/heroku-mcp-server/issues/308)) ([13e5f93](https://github.com/heroku/heroku-mcp-server/commit/13e5f93c57d5d9def02f6b819ec195f7bd42cc83))


### Dependencies

* bump @hono/node-server from 2.1.0 to 2.1.5 ([#309](https://github.com/heroku/heroku-mcp-server/issues/309)) ([edf0fcb](https://github.com/heroku/heroku-mcp-server/commit/edf0fcb03b3ae8c098ffee87ffaec3c7f19f3ab9))
* bump body-parser from 2.3.0 to 2.4.0 ([#303](https://github.com/heroku/heroku-mcp-server/issues/303)) ([642a0c2](https://github.com/heroku/heroku-mcp-server/commit/642a0c2aa23caf7fb7fbd56cc0bd230eda572cf2))
* bump fast-uri from 3.1.8 to 3.1.9 ([#301](https://github.com/heroku/heroku-mcp-server/issues/301)) ([7a252ef](https://github.com/heroku/heroku-mcp-server/commit/7a252efa37434585b422a6758bf7fa1344bceea4))
* bump ip-address from 10.7.2 to 10.7.5 ([#306](https://github.com/heroku/heroku-mcp-server/issues/306)) ([a074232](https://github.com/heroku/heroku-mcp-server/commit/a0742323f6b1f5f008bd86060a760ed54fd72e8b))
* bump node-forge from 1.4.0 to 1.4.2 ([#310](https://github.com/heroku/heroku-mcp-server/issues/310)) ([e3d83bd](https://github.com/heroku/heroku-mcp-server/commit/e3d83bdd0efb9d5804f80467e8b5a33fac7ea54c))
* bump tar-stream from 3.2.1 to 3.2.2 ([#295](https://github.com/heroku/heroku-mcp-server/issues/295)) ([c9638f4](https://github.com/heroku/heroku-mcp-server/commit/c9638f445a14b911662ac50db216ea37f46a5c5c))
* bump undici from 7.30.0 to 7.30.1 ([#302](https://github.com/heroku/heroku-mcp-server/issues/302)) ([774c90e](https://github.com/heroku/heroku-mcp-server/commit/774c90ebd37c499cf63dfeda8f29704b37469ae1))
* bump zod 3 -&gt; 4.6.7 (security) ([#307](https://github.com/heroku/heroku-mcp-server/issues/307)) ([970528f](https://github.com/heroku/heroku-mcp-server/commit/970528fc07bc75fd939f88f4308e301dedeffb3a))

## [1.2.12](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.11...mcp-server-v1.2.12) (2026-10-12)


### Dependencies

* bump @modelcontextprotocol/sdk from 1.31.0 to 1.32.1 ([#291](https://github.com/heroku/heroku-mcp-server/issues/291)) ([225b650](https://github.com/heroku/heroku-mcp-server/commit/225b650dd17f7079cc60de00bdb72a9ee80725f4))
* bump proxy-addr from 2.0.7 to 2.0.8 ([#290](https://github.com/heroku/heroku-mcp-server/issues/290)) ([f6f1edf](https://github.com/heroku/heroku-mcp-server/commit/f6f1edfcffe5fac64789c7271fcf6a646fdce7aa))

## [1.2.11](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.10...mcp-server-v1.2.11) (2026-10-06)


### Bug Fixes

* restore .js extensions on SDK subpath imports to fix ERR_MODULE_NOT_FOUND ([#284](https://github.com/heroku/heroku-mcp-server/issues/284)) ([26fe3ce](https://github.com/heroku/heroku-mcp-server/commit/26fe3ce9d857fbec271d04507e35b1067cb6c598))


### Dependencies

* bump @modelcontextprotocol/sdk from 1.30.1 to 1.31.0 ([#287](https://github.com/heroku/heroku-mcp-server/issues/287)) ([8414aca](https://github.com/heroku/heroku-mcp-server/commit/8414acaddaee8a917280d7f708411ee08ec97550))

## [1.2.10](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.9...mcp-server-v1.2.10) (2026-10-01)


### Dependencies

* bump @modelcontextprotocol/sdk from 1.30.0 to 1.30.1 ([#276](https://github.com/heroku/heroku-mcp-server/issues/276)) ([c8f8869](https://github.com/heroku/heroku-mcp-server/commit/c8f8869312ee0261000a7e7c3099b9703ee70550))
* bump ip-address from 10.5.0 to 10.7.2 ([#279](https://github.com/heroku/heroku-mcp-server/issues/279)) ([2847f44](https://github.com/heroku/heroku-mcp-server/commit/2847f44c0a7136df9b92a1d92daf5626f2dc5f11))
* bump undici from 7.29.0 to 7.30.0 ([#278](https://github.com/heroku/heroku-mcp-server/issues/278)) ([7373df6](https://github.com/heroku/heroku-mcp-server/commit/7373df60313c27559b92de8922942e4903d82a82))
* consolidated dependency bumps ([#283](https://github.com/heroku/heroku-mcp-server/issues/283)) ([e079083](https://github.com/heroku/heroku-mcp-server/commit/e0790830635ea41a3cafab79f58b2b2fd7a0c447))

## [1.2.9](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.8...mcp-server-v1.2.9) (2026-09-24)


### Bug Fixes

* quote flag and argument values in CommandBuilder (W-23972762) ([#269](https://github.com/heroku/heroku-mcp-server/issues/269)) ([cdb91a3](https://github.com/heroku/heroku-mcp-server/commit/cdb91a334f4ace3fb11f33a50d270f0b75d2dc71))


### Dependencies

* bump tar-stream from 3.2.0 to 3.2.1 ([#267](https://github.com/heroku/heroku-mcp-server/issues/267)) ([bdaefe3](https://github.com/heroku/heroku-mcp-server/commit/bdaefe383db529c6d78dd2966daafb5ccbf7884d))

## [1.2.8](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.7...mcp-server-v1.2.8) (2026-09-22)


### Dependencies

* bump fast-uri from 3.1.5 to 3.1.7 ([#258](https://github.com/heroku/heroku-mcp-server/issues/258)) ([a4c51a3](https://github.com/heroku/heroku-mcp-server/commit/a4c51a3a2a74a4596240a45bf6a9a1740cd9151c))
* bump hono from 4.13.0 to 4.13.7 ([#265](https://github.com/heroku/heroku-mcp-server/issues/265)) ([cc9818e](https://github.com/heroku/heroku-mcp-server/commit/cc9818e6f2b0c564b15e1c4e0ea2f85fb9e133cf))
* bump qs from 6.15.2 to 6.16.0 ([#259](https://github.com/heroku/heroku-mcp-server/issues/259)) ([e4ab1a6](https://github.com/heroku/heroku-mcp-server/commit/e4ab1a65ae09fcba9867e9d1354fce323cbc236d))
* bump tar-stream from 3.1.7 to 3.2.0 ([#252](https://github.com/heroku/heroku-mcp-server/issues/252)) ([e1a20d2](https://github.com/heroku/heroku-mcp-server/commit/e1a20d2c0d5b73b43ed2cca2feeaf2c66a9c9257))

## [1.2.7](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.6...mcp-server-v1.2.7) (2026-09-03)


### Bug Fixes

* stop deploy packer from following out-of-root symlinks ([#257](https://github.com/heroku/heroku-mcp-server/issues/257)) ([75ec26a](https://github.com/heroku/heroku-mcp-server/commit/75ec26a9d96d37c757f7c6c69044897875f2553a))

## [1.2.6](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.5...mcp-server-v1.2.6) (2026-08-11)


### Dependencies

* bump body-parser from 2.2.2 to 2.3.0 ([#235](https://github.com/heroku/heroku-mcp-server/issues/235)) ([7b0abaf](https://github.com/heroku/heroku-mcp-server/commit/7b0abafdd5256b259a666efeb409e7dafe76b9db))
* bump brace-expansion ([#246](https://github.com/heroku/heroku-mcp-server/issues/246)) ([cb5c07c](https://github.com/heroku/heroku-mcp-server/commit/cb5c07c813187b3e14c042c64437672186bed37d))
* bump fast-uri from 3.1.2 to 3.1.5 ([#242](https://github.com/heroku/heroku-mcp-server/issues/242)) ([ce30e75](https://github.com/heroku/heroku-mcp-server/commit/ce30e7526017d4c4ce1c39760bb6ff4b0f41f778))
* bump ip-address from 10.2.0 to 10.5.0 ([#247](https://github.com/heroku/heroku-mcp-server/issues/247)) ([effd956](https://github.com/heroku/heroku-mcp-server/commit/effd956d26a17eaa991597ca22bf18c26ee3eef0))
* bump undici from 7.28.0 to 7.29.0 ([#240](https://github.com/heroku/heroku-mcp-server/issues/240)) ([f248a4b](https://github.com/heroku/heroku-mcp-server/commit/f248a4b16f54392d0af5b419426f6b08f2a9ec31))
* fixes multiple Dependabot security advisories ([#248](https://github.com/heroku/heroku-mcp-server/issues/248)) ([edd1312](https://github.com/heroku/heroku-mcp-server/commit/edd13122768cc1f31a6263f98500ffa0521f4d7f))

## [1.2.5](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.4...mcp-server-v1.2.5) (2026-06-29)


### Dependencies

* bump hono from 4.12.23 to 4.12.26 ([#221](https://github.com/heroku/heroku-mcp-server/issues/221)) ([0177697](https://github.com/heroku/heroku-mcp-server/commit/017769775a882d507a632a1d3efae4bf2c8cd747))
* bump undici from 7.24.4 to 7.28.0 ([#222](https://github.com/heroku/heroku-mcp-server/issues/222)) ([84cf770](https://github.com/heroku/heroku-mcp-server/commit/84cf7708d19ed73422d00f68a419efda73704578))

## [1.2.4](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.3...mcp-server-v1.2.4) (2026-06-22)


### Bug Fixes

* invoke heroku CLI repl as subcommand instead of --repl flag ([#220](https://github.com/heroku/heroku-mcp-server/issues/220)) ([6f3f4e2](https://github.com/heroku/heroku-mcp-server/commit/6f3f4e21914118bb2227ab5f1484fc3e756b58a6))

## [1.2.3](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.2...mcp-server-v1.2.3) (2026-06-08)


### Dependencies

* bump fast-uri from 3.1.0 to 3.1.2 ([#202](https://github.com/heroku/heroku-mcp-server/issues/202)) ([0582a7f](https://github.com/heroku/heroku-mcp-server/commit/0582a7f0e51d5ed6598a37de8ce59fb012559e6a))
* bump hono from 4.12.14 to 4.12.18 ([#201](https://github.com/heroku/heroku-mcp-server/issues/201)) ([00dd41b](https://github.com/heroku/heroku-mcp-server/commit/00dd41be3b8fef8aac8e4d2080c203303aa1a5c9))
* bump hono from 4.12.18 to 4.12.23 ([#214](https://github.com/heroku/heroku-mcp-server/issues/214)) ([31ece96](https://github.com/heroku/heroku-mcp-server/commit/31ece9687c6e3f3d0a115dcd99cea81b135d6c09))
* bump ip-address and express-rate-limit ([#200](https://github.com/heroku/heroku-mcp-server/issues/200)) ([fb3f66a](https://github.com/heroku/heroku-mcp-server/commit/fb3f66ad64092141bf8c1b29f950f6a43b34e3ef))
* bump qs from 6.14.2 to 6.15.2 ([#212](https://github.com/heroku/heroku-mcp-server/issues/212)) ([6e7a2f1](https://github.com/heroku/heroku-mcp-server/commit/6e7a2f19d3acdc650cdebc053041a124183aba0e))
* fix npm audit vulnerabilities ([#217](https://github.com/heroku/heroku-mcp-server/issues/217)) ([17eb8d8](https://github.com/heroku/heroku-mcp-server/commit/17eb8d85c74e0a2a7ffb4e88d6340f793854fe74))

## [1.2.2](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.1...mcp-server-v1.2.2) (2026-04-22)


### Bug Fixes

* validate one-off dyno source paths before shell staging ([#192](https://github.com/heroku/heroku-mcp-server/issues/192)) ([b523109](https://github.com/heroku/heroku-mcp-server/commit/b5231090b0c97ceceab8ec7fcf43af84fefade20))

## [1.2.1](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.2.0...mcp-server-v1.2.1) (2026-03-17)

### Miscellaneous Chores

- release 1.2.1 ([#178](https://github.com/heroku/heroku-mcp-server/issues/178))
  ([8316f13](https://github.com/heroku/heroku-mcp-server/commit/8316f1346cc95cc7d9df1ad21261f10edab74043))

## [1.2.0](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.1.0...mcp-server-v1.2.0) (2026-02-18)

### Features

- add plugin installation detection and handle command not found errors
  ([#146](https://github.com/heroku/heroku-mcp-server/issues/146))
  ([8ab7898](https://github.com/heroku/heroku-mcp-server/commit/8ab78985edf524a81f42d480e30458879d025ca5))

## [1.1.0](https://github.com/heroku/heroku-mcp-server/compare/mcp-server-v1.0.7...mcp-server-v1.1.0) (2026-01-16)

### Features

- Add heroku_dev_center Resource ([#84](https://github.com/heroku/heroku-mcp-server/issues/84))
  ([a13c6d9](https://github.com/heroku/heroku-mcp-server/commit/a13c6d9ad1c706d31c395baa06e4b9fe5ed33b24))
- add the agents call command ([#56](https://github.com/heroku/heroku-mcp-server/issues/56))
  ([ffafd8b](https://github.com/heroku/heroku-mcp-server/commit/ffafd8b9a1b8a3eeb29ece57af3d6d10d892aa58))
- Add-ons topic tool implementations
  ([f043b8a](https://github.com/heroku/heroku-mcp-server/commit/f043b8af3ebaf8f546eb9b45da99950b1fe8cc1d))
- Apps tools and related context tools
  ([164f782](https://github.com/heroku/heroku-mcp-server/commit/164f782f50b4e1b70e836d89b8a34548e5db9a3f))
- Execute generated code on a one-off Dyno ([#22](https://github.com/heroku/heroku-mcp-server/issues/22))
  ([5139964](https://github.com/heroku/heroku-mcp-server/commit/5139964a92cf55dac0414a7443e50a0210cbe1d7))
- Overwriting User-Agent on CLI requests for MCP mode
  ([4551460](https://github.com/heroku/heroku-mcp-server/commit/455146012e03e5a40234ce21d4bf82106dd0270e))
- prepare for .dxt file creation and compatibility ([#81](https://github.com/heroku/heroku-mcp-server/issues/81))
  ([8a9b8d6](https://github.com/heroku/heroku-mcp-server/commit/8a9b8d678d1a9ed34a1e5605667199c3c59a5b82))
- require global install of heroku cli for a4d ([#63](https://github.com/heroku/heroku-mcp-server/issues/63))
  ([3e25587](https://github.com/heroku/heroku-mcp-server/commit/3e25587dd2e64f50dfbd5ec221ea10e5ba6e72a7))
- short, concise descriptions minimizing token counts ([#35](https://github.com/heroku/heroku-mcp-server/issues/35))
  ([bd1d878](https://github.com/heroku/heroku-mcp-server/commit/bd1d878a86d3bde9c7587e923ad92f7f0ccab0de))
- **W-18081411,W-18081589:** integrate the Heroku CLI into the MCP server
  ([6e37775](https://github.com/heroku/heroku-mcp-server/commit/6e37775a57305c2fabebc8bd0700d42a0e0f308a))
- **W-18081411,W-18081589:** integrate the Heroku CLI into the MCP server
  ([dbb8713](https://github.com/heroku/heroku-mcp-server/commit/dbb8713031cd9ae0598129b0b0acf31464589a17))
- **W-18097559:** add data commands
  ([740a0a0](https://github.com/heroku/heroku-mcp-server/commit/740a0a0081e6f95d3165460785cf9a77186f09a7))
- **W-18097559:** add data commands
  ([773e27d](https://github.com/heroku/heroku-mcp-server/commit/773e27d425b8e7a5e0e385c916361e397ce2f29e))
- **W-18097560:** added pipelines and ps commands
  ([c5131af](https://github.com/heroku/heroku-mcp-server/commit/c5131af1ae0579109d7400c5c59c33b78530c38b))
- **W-18097560:** added pipelines and ps commands
  ([45acbbe](https://github.com/heroku/heroku-mcp-server/commit/45acbbe5669d3ec012c4eb8f89aea7a99b0db79b))
- **W-18187196:** Implement deploy to heroku tool
  ([0679311](https://github.com/heroku/heroku-mcp-server/commit/06793113c0214ea9caa68ba4d96a1aca643e0ea7))
- **W-18187196:** Implement deploy to heroku tool
  ([331c047](https://github.com/heroku/heroku-mcp-server/commit/331c0476735d840a6842b22359932e7624d051d2))

### Bug Fixes

- 45 - MCP doesnt connect on windows ([#48](https://github.com/heroku/heroku-mcp-server/issues/48))
  ([9c5bc89](https://github.com/heroku/heroku-mcp-server/commit/9c5bc89082b7a872faaa6226932dc74726514caf))
- added the cli buildpack to ensure CLI availability ([#74](https://github.com/heroku/heroku-mcp-server/issues/74))
  ([be2be16](https://github.com/heroku/heroku-mcp-server/commit/be2be16870ad0dd48f8f08aa036c912dc6d1fabb))
- readme instructions
  ([043015d](https://github.com/heroku/heroku-mcp-server/commit/043015dfd2a9b1769c9aedef7a46320e89065f5d))
- readme instructions
  ([fa44f1c](https://github.com/heroku/heroku-mcp-server/commit/fa44f1c7133386b103d8335a7643654f762e8ada))
- use the correct mcpServers json format ([#41](https://github.com/heroku/heroku-mcp-server/issues/41))
  ([bfb1312](https://github.com/heroku/heroku-mcp-server/commit/bfb1312e051a11804a8f7a85b0a53da329201723))

### Documentation

- Add CHANGELOG.md ([#130](https://github.com/heroku/heroku-mcp-server/issues/130))
  ([1abde73](https://github.com/heroku/heroku-mcp-server/commit/1abde73795c9a4052164bf11bda4f3c10a0bc869))

### Miscellaneous Chores

- add execution comment for heroku-mcp-server.mjs file ([#91](https://github.com/heroku/heroku-mcp-server/issues/91))
  ([7f956f7](https://github.com/heroku/heroku-mcp-server/commit/7f956f759cb8b604b98096f701d56d0e22d47c5d))
- **apps:** update apps_list tool to prevent usage for app name checks
  ([fad7f08](https://github.com/heroku/heroku-mcp-server/commit/fad7f0898c6945f77e2898be98532a7791bceef2))
- **apps:** update apps_list tool to prevent usage for app name checks
  ([8ca092b](https://github.com/heroku/heroku-mcp-server/commit/8ca092b3b37a3e1d01a1e1604f0e615d18784f29))
- **auth:** update readme to include alternate method for retrieving a token
  ([77d544a](https://github.com/heroku/heroku-mcp-server/commit/77d544aed7b42bed25fed89458f1e6bc4f089fb3))
- **auth:** update readme to include alternate method for retrieving a token
  ([3266dce](https://github.com/heroku/heroku-mcp-server/commit/3266dcec439336c6fa25ae997df68352649815e0))
- **deps-dev:** bump @modelcontextprotocol/inspector from 0.7.0 to 0.14.1
  ([#75](https://github.com/heroku/heroku-mcp-server/issues/75))
  ([74136bc](https://github.com/heroku/heroku-mcp-server/commit/74136bc14471b020408ce9fb4fc90b7b37f680c2))
- **deps:** bump @modelcontextprotocol/sdk from 1.16.0 to 1.24.0
  ([#122](https://github.com/heroku/heroku-mcp-server/issues/122))
  ([a6eb7a3](https://github.com/heroku/heroku-mcp-server/commit/a6eb7a3b55139a8cf14737dd9ed6ec297eab0ae1))
- **deps:** bump glob from 10.4.5 to 10.5.0 ([#113](https://github.com/heroku/heroku-mcp-server/issues/113))
  ([7af6d3b](https://github.com/heroku/heroku-mcp-server/commit/7af6d3bb5a58e5df043df5aec1e290d316dc60be))
- **deps:** bump qs from 6.14.0 to 6.14.1 ([#133](https://github.com/heroku/heroku-mcp-server/issues/133))
  ([2a5938b](https://github.com/heroku/heroku-mcp-server/commit/2a5938b7b1db5d8146d6d579c79149fc79789163))
- **deps:** bump the patch-dependencies group across 1 directory with 5 updates
  ([#49](https://github.com/heroku/heroku-mcp-server/issues/49))
  ([8a710f2](https://github.com/heroku/heroku-mcp-server/commit/8a710f20e4ef0ddabf2f8d9d384537b1ee84111f))
- **deps:** bump zod from 3.24.4 to 3.25.56 ([#69](https://github.com/heroku/heroku-mcp-server/issues/69))
  ([b779d2d](https://github.com/heroku/heroku-mcp-server/commit/b779d2d64cc44735d436c3ebdfd6ef7f257cb818))
- **descriptions:** update tool descriptions to be consistent
  ([978f3a4](https://github.com/heroku/heroku-mcp-server/commit/978f3a4548daeded0508ffd601d4c9610b4521d2))
- **descriptions:** update tool descriptions to be consistent/Updated README
  ([53807a6](https://github.com/heroku/heroku-mcp-server/commit/53807a67f105fc0bdb7933506da603a2a1fca47f))
- onboard shared workflows ([#137](https://github.com/heroku/heroku-mcp-server/issues/137))
  ([d6351df](https://github.com/heroku/heroku-mcp-server/commit/d6351df8f9da04aae0f5a270907c0de0c99e8494))
- Update readme to include instructions for cline, vscode and trae
  ([#39](https://github.com/heroku/heroku-mcp-server/issues/39))
  ([c84d2aa](https://github.com/heroku/heroku-mcp-server/commit/c84d2aa63689dfc907e6ad655e517a48c6f6d104))
- updated config docs to show alternate config using the CLI
  ([#72](https://github.com/heroku/heroku-mcp-server/issues/72))
  ([d7b23ec](https://github.com/heroku/heroku-mcp-server/commit/d7b23ecc42a6f4f299fc92ebeb81ef1d073587aa))
- updated readme to include deploy_one_off_dyno and remove unneeded install instructions
  ([#33](https://github.com/heroku/heroku-mcp-server/issues/33))
  ([57e3f58](https://github.com/heroku/heroku-mcp-server/commit/57e3f58b542b6a73fe5a299005ea07b789e4b516))

## [1.0.7](https://github.com/heroku/heroku-mcp-server/compare/v1.0.6...v1.0.7) (2025-07-21)

### Features

- Add heroku_dev_center Resource ([#84](https://github.com/heroku/heroku-mcp-server/issues/84))
  ([a13c6d9](https://github.com/heroku/heroku-mcp-server/commit/a13c6d9ad1c706d31c395baa06e4b9fe5ed33b24))
- prepare for .dxt file creation and compatibility ([#81](https://github.com/heroku/heroku-mcp-server/issues/81))
  ([8a9b8d6](https://github.com/heroku/heroku-mcp-server/commit/8a9b8d678d1a9ed34a1e5605667199c3c59a5b82))
- require global install of heroku cli for a4d ([#63](https://github.com/heroku/heroku-mcp-server/issues/63))
  ([3e25587](https://github.com/heroku/heroku-mcp-server/commit/3e25587dd2e64f50dfbd5ec221ea10e5ba6e72a7))

### Bug Fixes

- added the cli buildpack to ensure CLI availability ([#74](https://github.com/heroku/heroku-mcp-server/issues/74))
  ([be2be16](https://github.com/heroku/heroku-mcp-server/commit/be2be16870ad0dd48f8f08aa036c912dc6d1fabb))

### Miscellaneous Chores

- updated config docs to show alternate config using the CLI
  ([#72](https://github.com/heroku/heroku-mcp-server/issues/72))
  ([d7b23ec](https://github.com/heroku/heroku-mcp-server/commit/d7b23ecc42a6f4f299fc92ebeb81ef1d073587aa))
- add cursor button ([#68](https://github.com/heroku/heroku-mcp-server/issues/68))
  ([6a865c2](https://github.com/heroku/heroku-mcp-server/commit/6a865c26b0c5fabe8e7c81b3b8c6d9e8d4f8a1d2))
- **deps:** bump zod from 3.24.4 to 3.25.56 ([#69](https://github.com/heroku/heroku-mcp-server/issues/69))
  ([b779d2d](https://github.com/heroku/heroku-mcp-server/commit/b779d2d64cc44735d436c3ebdfd6ef7f257cb818))
- **deps-dev:** bump @modelcontextprotocol/inspector from 0.7.0 to 0.14.1
  ([#75](https://github.com/heroku/heroku-mcp-server/issues/75))
  ([74136bc](https://github.com/heroku/heroku-mcp-server/commit/74136bc14471b020408ce9fb4fc90b7b37f680c2))
- Upgrade @modelcontextprotocol/sdk package ([#88](https://github.com/heroku/heroku-mcp-server/issues/88))
  ([b5d492d](https://github.com/heroku/heroku-mcp-server/commit/b5d492d1e4d3c7f8a9b2e6f4c8d1a3e5f7b9c0d2))

## [1.0.6](https://github.com/heroku/heroku-mcp-server/compare/v1.0.5...v1.0.6) (2025-05-22)

### Miscellaneous Chores

- Updating Core CLI dependency version ([#58](https://github.com/heroku/heroku-mcp-server/issues/58))
  ([06d6dd9](https://github.com/heroku/heroku-mcp-server/commit/06d6dd9ad1c706d31c395baa06e4b9fe5ed33b24))

## [1.0.5](https://github.com/heroku/heroku-mcp-server/compare/v1.0.4...v1.0.5) (2025-05-22)

### Features

- add the agents call command ([#56](https://github.com/heroku/heroku-mcp-server/issues/56))
  ([ffafd8b](https://github.com/heroku/heroku-mcp-server/commit/ffafd8b9a1b8a3eeb29ece57af3d6d10d892aa58))
- Add tools for listing and provisioning AI models ([#54](https://github.com/heroku/heroku-mcp-server/issues/54))
  ([25f2823](https://github.com/heroku/heroku-mcp-server/commit/25f28230d1e4c3b6a8f9c2e5d7b0a4f3c6e8d1a0))
- Various improvements for mia compatibility ([#53](https://github.com/heroku/heroku-mcp-server/issues/53))
  ([f06c556](https://github.com/heroku/heroku-mcp-server/commit/f06c556b9a8e7d4c3f2b1a0e9d8c7b6a5f4e3d2c))
- Deployment: Dockerfile and Smithery config ([#34](https://github.com/heroku/heroku-mcp-server/issues/34))
  ([18d9e7d](https://github.com/heroku/heroku-mcp-server/commit/18d9e7d0e8c7b6a5f4d3c2b1a0e9f8d7c6b5a4e3))

### Miscellaneous Chores

- **deps:** bump the patch-dependencies group across 1 directory with 5 updates
  ([#49](https://github.com/heroku/heroku-mcp-server/issues/49))
  ([8a710f2](https://github.com/heroku/heroku-mcp-server/commit/8a710f20e4ef0ddabf2f8d9d384537b1ee84111f))

## [1.0.4](https://github.com/heroku/heroku-mcp-server/compare/v1.0.3...v1.0.4) (2025-05-06)

### Bug Fixes

- MCP doesn't connect on windows ([#48](https://github.com/heroku/heroku-mcp-server/issues/48))
  ([9c5bc89](https://github.com/heroku/heroku-mcp-server/commit/9c5bc89082b7a872faaa6226932dc74726514caf)), closes
  [#45](https://github.com/heroku/heroku-mcp-server/issues/45)

## [1.0.3](https://github.com/heroku/heroku-mcp-server/compare/v1.0.2...v1.0.3) (2025-04-28)

### Bug Fixes

- use the correct mcpServers json format ([#41](https://github.com/heroku/heroku-mcp-server/issues/41))
  ([bfb1312](https://github.com/heroku/heroku-mcp-server/commit/bfb1312e051a11804a8f7a85b0a53da329201723))

## [1.0.2](https://github.com/heroku/heroku-mcp-server/compare/v1.0.1...v1.0.2) (2025-04-22)

### Features

- short, concise descriptions minimizing token counts ([#35](https://github.com/heroku/heroku-mcp-server/issues/35))
  ([bd1d878](https://github.com/heroku/heroku-mcp-server/commit/bd1d878a86d3bde9c7587e923ad92f7f0ccab0de))

### Miscellaneous Chores

- Update readme to include instructions for cline, vscode and trae
  ([#39](https://github.com/heroku/heroku-mcp-server/issues/39))
  ([c84d2aa](https://github.com/heroku/heroku-mcp-server/commit/c84d2aa63689dfc907e6ad655e517a48c6f6d104))
- updated readme to include deploy_one_off_dyno and remove unneeded install instructions
  ([#33](https://github.com/heroku/heroku-mcp-server/issues/33))
  ([57e3f58](https://github.com/heroku/heroku-mcp-server/commit/57e3f58b542b6a73fe5a299005ea07b789e4b516))

## [1.0.1](https://github.com/heroku/heroku-mcp-server/compare/v1.0.0...v1.0.1) (2025-04-16)

### Bug Fixes

- node engines mismatch ([#31](https://github.com/heroku/heroku-mcp-server/issues/31))
  ([7fc4521](https://github.com/heroku/heroku-mcp-server/commit/7fc45210b9c8d7e6f5a4b3c2d1e0f9a8b7c6d5e4)), closes
  [#27](https://github.com/heroku/heroku-mcp-server/issues/27)

## [1.0.0](https://github.com/heroku/heroku-mcp-server/compare/v0.0.1...v1.0.0) (2025-04-10)

### Features

- Execute generated code on a one-off Dyno ([#22](https://github.com/heroku/heroku-mcp-server/issues/22))
  ([5139964](https://github.com/heroku/heroku-mcp-server/commit/5139964a92cf55dac0414a7443e50a0210cbe1d7))
- Overwriting User-Agent on CLI requests for MCP mode ([#21](https://github.com/heroku/heroku-mcp-server/issues/21))
  ([4551460](https://github.com/heroku/heroku-mcp-server/commit/455146012e03e5a40234ce21d4bf82106dd0270e))

### Bug Fixes

- readme instructions ([#19](https://github.com/heroku/heroku-mcp-server/issues/19))
  ([043015d](https://github.com/heroku/heroku-mcp-server/commit/043015dfd2a9b1769c9aedef7a46320e89065f5d))

### Miscellaneous Chores

- CX Review ([#23](https://github.com/heroku/heroku-mcp-server/issues/23))
  ([b1f7b45](https://github.com/heroku/heroku-mcp-server/commit/b1f7b45e8d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a))
- Updating Heroku CLI dependency version
  ([93340f0](https://github.com/heroku/heroku-mcp-server/commit/93340f0b6ef6c1c9b56542819d0ce13ca7711148))
- Updating repository instructions on installation ([#20](https://github.com/heroku/heroku-mcp-server/issues/20))
  ([f813acc](https://github.com/heroku/heroku-mcp-server/commit/f813acce7d8c9b0a1f2e3d4c5b6a7f8e9d0c1b2a))

## [0.0.1](https://github.com/heroku/heroku-mcp-server/releases/tag/v0.0.1) (2025-04-07)

### Features

- **W-18081411,W-18081589:** integrate the Heroku CLI into the MCP server
  ([6e37775](https://github.com/heroku/heroku-mcp-server/commit/6e37775a57305c2fabebc8bd0700d42a0e0f308a))
- **W-18097559:** add data commands
  ([740a0a0](https://github.com/heroku/heroku-mcp-server/commit/740a0a0081e6f95d3165460785cf9a77186f09a7))
- **W-18097560:** added pipelines and ps commands
  ([c5131af](https://github.com/heroku/heroku-mcp-server/commit/c5131af1ae0579109d7400c5c59c33b78530c38b))
- **W-18187196:** Implement deploy to heroku tool
  ([0679311](https://github.com/heroku/heroku-mcp-server/commit/06793113c0214ea9caa68ba4d96a1aca643e0ea7))
- Apps tools and related context tools
  ([164f782](https://github.com/heroku/heroku-mcp-server/commit/164f782f50b4e1b70e836d89b8a34548e5db9a3f))
- Add-ons topic tool implementations
  ([f043b8a](https://github.com/heroku/heroku-mcp-server/commit/f043b8af3ebaf8f546eb9b45da99950b1fe8cc1d))
- Adding tools for topic 'teams' with tests
  ([63ce9ba](https://github.com/heroku/heroku-mcp-server/commit/63ce9bab8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f))
- Adding tools for topic 'spaces' with tests
  ([e8ba789](https://github.com/heroku/heroku-mcp-server/commit/e8ba7897c6b5d4e3f2a1b0c9d8e7f6a5b4c3d2e1))
- Adding logs tool to MCP Server
  ([ade3ccf](https://github.com/heroku/heroku-mcp-server/commit/ade3ccf9d8e7c6b5a4f3e2d1c0b9a8f7e6d5c4b3))

### Miscellaneous Chores

- **apps:** update apps_list tool to prevent usage for app name checks
  ([fad7f08](https://github.com/heroku/heroku-mcp-server/commit/fad7f0898c6945f77e2898be98532a7791bceef2))
- **auth:** update readme to include alternate method for retrieving a token
  ([77d544a](https://github.com/heroku/heroku-mcp-server/commit/77d544aed7b42bed25fed89458f1e6bc4f089fb3))
- **descriptions:** update tool descriptions to be consistent
  ([978f3a4](https://github.com/heroku/heroku-mcp-server/commit/978f3a4548daeded0508ffd601d4c9610b4521d2))
- Initial repository structure
  ([d1c0357](https://github.com/heroku/heroku-mcp-server/commit/d1c0357a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e))
