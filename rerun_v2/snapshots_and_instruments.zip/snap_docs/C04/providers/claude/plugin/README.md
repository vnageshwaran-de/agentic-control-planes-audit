# Stripe plugin for Claude Code

This plugin gives Claude Code first-party knowledge of Stripe and its supporting
products, so an agent can plan, build, and review a Stripe integration the way a
Stripe engineer would, instead of guessing from stale training data about an API
that changes monthly. It pairs that knowledge with the
[Stripe MCP server](https://docs.stripe.com/mcp), which exposes a curated set of
Stripe API endpoints directly to the agent for live lookups and operations.

## What's in here

Stripe's skills are updated often by the relevant product teams; some examples are:

- **`stripe-best-practices`** — integration decisions: environments, API choice
  (Checkout Sessions vs. PaymentIntents), Connect setup, billing, tax, Treasury,
  and security.
- **`metronome`** — usage-based billing on Metronome: event ingestion,
  contracts/rate cards, invoicing, credits/commits, and syncing to Stripe
  Billing.
- **`connect-recommend`** — turns a company URL or business description into a
  concrete Connect configuration.

It also helps an agent reach Stripe's other offerings: **`stripe-directory`**
(find and engage an external business or service), **`stripe-apps`** (build and
review Stripe Apps and Dashboard extensions), and **`stripe-projects`**
(provision third-party infrastructure and credentials).

## Telemetry

By default, the plugin reports skill usage and can prompt for feedback:

1. **Skill usage events:** When Claude Code invokes a Stripe skill, the plugin
   sends the skill name to Stripe.
2. **Feedback prompts:** The plugin sometimes prompts the agent to draft
   feedback, for example after a failed Stripe tool call. The agent shows you
   the draft and asks for approval before sending it.

Separately, at session start we check for a newer Stripe CLI version and, if
found, suggest the agent recommend installing it. We never install anything
ourselves.

**To turn off skill usage events and feedback prompts**, set `DISABLE_TELEMETRY` or
`DO_NOT_TRACK` to `1` or `true` in your environment. The CLI version check isn't
telemetry (no usage data is sent) and isn't affected.

## Plugin auth

This plugin **does not** read credentials from the user's environment or files, and
it does not forward any credential to a server. All authentication must happen safely through OAuth 2.0.

- **MCP server** (`.mcp.json`): a single remote HTTP server,
  `https://mcp.stripe.com`, operated by Stripe. It declares no `env`, no
  `headers`, and no API key or token of any kind. Authentication is OAuth 2.0
  only, handled by Claude Code's built-in MCP OAuth flow, so the plugin never
  sees or transmits a secret.
- **`skills/stripe-apps/references/authentication.md`**: this is reference
  documentation for developers building Stripe Apps. Snippets which mention 
  example code are describing integration code that a developer would write in
  their app's server. They aren't actual plugin code, the plugin never actually
  reads values from the user's environment.
